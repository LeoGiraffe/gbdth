﻿using practice3.ApplicationData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Documents.DocumentStructures;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practice3
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window

    {
        AppConnect database = new AppConnect();

 
        public Window1()
        {
            InitializeComponent();
           
            ;
        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void btnBackButton_Click(object sender, RoutedEventArgs e)
        {
            Window windowlog = new MainWindow();
            windowlog.Show();
            this.Close();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var login = txbLogin.Text;
            var password = psbPass.Password;
            var job = txbJob.Text;

            string querystring = $"insert into users(login, password, job) values ('{login}', '{password}', '{job}')";


            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            database.openConnection();
            if(command.ExecuteNonQuery()==1)
            {
                MessageBox.Show("Аккаунт успешно создан!", "Успех");
                MainWindow mwindow = new MainWindow();
                this.Hide();
                mwindow.Show();
            }
            else
            {
                MessageBox.Show("Аккаунт не создан");
            }
            database.closeConnection();

        }
        private Boolean checkuser()
        {
            var login = txbLogin.Text;
            var password = psbPass.Password;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable(); 
            string querystring = $"select id login, password from users where login = '{login}' and password = '{password}'";
            SqlCommand command = new SqlCommand(querystring, database.getConnection());
             adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Пользователь существует");
                return true;

            }
            else
            {
                return false;
            }
        }
    }
}
