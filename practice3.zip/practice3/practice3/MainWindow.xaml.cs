﻿using practice3.ApplicationData;
using System.Windows;
using System.Data.SqlClient;
using System.Data;


namespace practice3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AppConnect database = new AppConnect();


        public MainWindow()
        {
            InitializeComponent();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window window1 = new Window1();
            window1.Show();
            this.Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var login = tbxLogin.Text;
            var password = passwordTextBox.Password;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select id, login, password from users where login  = '{login}' and password = '{password}'";
            SqlCommand command = new SqlCommand(querystring, database.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Добро пожаловать", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                Window2 window2 = new Window2();
                this.Hide();
                window2.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("Такого пользователя не существует", "Не успешно", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        void hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Window window1 = new Window1();
            window1.Show();
            this.Close();

        }
    }

}