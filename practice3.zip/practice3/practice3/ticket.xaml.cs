﻿using practice3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practice3
{
    /// <summary> 
    /// Логика взаимодействия для Window4.xaml 
    /// </summary> 
    public partial class ticket : Window
    {
        public ticket(List<items> items)
        {

            InitializeComponent();
            Itemegrid.ItemsSource = items;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Window2 main = new Window2();
            main.Show();
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window2 main = new Window2();
            main.Show();
            this.Hide();
        }
    }
}