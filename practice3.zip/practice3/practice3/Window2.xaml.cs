﻿
using System; 
using System.Windows; 
using System.Windows.Controls; 
using System.Data; 
using System.Data.SqlClient; 
using System.Configuration; 
using System.Collections.Generic; 
using System.Runtime.InteropServices; 
using System.Windows.Documents; 
 
namespace practice3
{
    public partial class Window2 : Window
    {
        List<items> list = new List<items>();
        SqlDataAdapter adapter;

        public Window2()
        {
            InitializeComponent();
            // получаем строку подключения из app.config 
            GetList();
        }

        SqlConnection con;
        SqlCommand com;
        DataSet ds;
        public void GetList()
        {
            con = new SqlConnection(@"Data Source=192.168.10.151\SQLEXPRESS;Initial Catalog=practice; User ID=wsr-1; Password=$cYm*kL$Ny5QP#; Integrated Security=False");
            adapter = new SqlDataAdapter("Select * From item", con);
            ds = new DataSet();
            con.Open();
            adapter.Fill(ds, "item");
            List<items> a = new List<items>();
            foreach (System.Data.DataRow A in ds.Tables[0].Rows)
            {
                items a1 = new items
                {
                    name = A.Field<string>("name"),
                    count = A.Field<int>("count"),
                    price = A.Field<int>("price"),
                    values = A.Field<int>("values")
                };
                a.Add(a1);

            }

            Itemegrid.ItemsSource = a;
            con.Close();
        }


        
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ticket main = new ticket(list);
            main.Show();
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_2(object sender,RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void adds(object sender, DataGridCellEditEndingEventArgs e)
        {

            items a = e.Row.Item as items;
            list.Add(a);
        }
    }
}
