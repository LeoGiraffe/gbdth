﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice3
{
    public class Class1
    {
        public int id { get; set; }
        public string name { get; set; }
        public string Category { get; set; }
        public int count { get; set; }
        public int price { get; set; }
    }
}
